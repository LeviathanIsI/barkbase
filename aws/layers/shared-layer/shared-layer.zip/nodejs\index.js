/**
 * =============================================================================
 * BarkBase Shared Layer - Index
 * =============================================================================
 *
 * Exports all shared layer utilities for easy importing in Lambda functions.
 *
 * =============================================================================
 */

const authHandler = require('./auth-handler');
const jwtValidator = require('./jwt-validator');
const securityUtils = require('./security-utils');
const securityHeaders = require('./security-headers');
const rateLimiter = require('./rate-limiter');
const emailUtils = require('./email-utils');
const permissions = require('./permissions');
const smsUtils = require('./sms-utils');
const squareUtils = require('./square-utils');
const quickbooksUtils = require('./quickbooks-utils');
const webhookUtils = require('./webhook-utils');
const usdaForms = require('./usda-forms');
const vaccinationRules = require('./vaccination-rules');
const auditUtils = require('./audit-utils');
const tierEnforcement = require('./tier-enforcement');
const workflowEvents = require('./workflow-events');
const accountResolver = require('./account-resolver');
const cryptoUtils = require('./crypto-utils');
const secrets = require('./secrets');


/**
 * Rewrites /admin/v1/* paths to /api/v1/* for internal routing.
 * MUST be called at the very start of every Lambda handler before any routing.
 *
 * SECURITY: This function validates IAM authentication before marking as admin.
 * The X-Admin-User header is only trusted after IAM validation passes.
 *
 * @param {object} event - The Lambda event object (will be mutated)
 * @returns {boolean} - True if this is a valid admin request
 */
function handleAdminPathRewrite(event) {
  const path = event.path || event.requestContext?.http?.path || '';

  if (!path.startsWith('/admin/v1/')) {
    return false;
  }

  // SECURITY: Validate IAM authentication
  // API Gateway sets these when using AWS_IAM authorization
  const requestContext = event.requestContext || {};
  const identity = requestContext.identity || {};
  const iamAuthorizer = requestContext.authorizer?.iam || {};

  // Check for IAM authentication markers set by API Gateway
  const hasIamAuth = !!(
    identity.userArn ||
    identity.caller ||
    identity.accountId ||
    iamAuthorizer.userArn ||
    iamAuthorizer.cognitoIdentityId
  );

  if (!hasIamAuth) {
    console.warn('[ADMIN] Path rewrite REJECTED - no IAM authentication present');
    console.warn('[ADMIN] Path:', path);
    return false;
  }

  const callerArn = identity.userArn || iamAuthorizer.userArn || '';
  console.log('[ADMIN] IAM-authenticated request from:', callerArn);

  const originalPath = path;

  // Rewrite all path references
  if (event.path) {
    event.path = event.path.replace('/admin/v1/', '/api/v1/');
  }

  if (event.rawPath) {
    event.rawPath = event.rawPath.replace('/admin/v1/', '/api/v1/');
  }

  if (event.requestContext?.http?.path) {
    event.requestContext.http.path = event.requestContext.http.path.replace('/admin/v1/', '/api/v1/');
  }

  if (event.routeKey) {
    event.routeKey = event.routeKey.replace('/admin/v1/', '/api/v1/');
  }

  console.log(`[ADMIN] Path rewritten: ${originalPath} -> ${event.path || event.requestContext?.http?.path}`);

  // Mark this as an admin request for downstream handlers
  event.isAdminRequest = true;

  // Now we can trust the X-Admin-User header for audit logging
  const adminUser = event.headers?.['x-admin-user'] || event.headers?.['X-Admin-User'];
  if (adminUser) {
    event.adminUser = adminUser;
    event.adminOperator = adminUser;
    console.log('[ADMIN] Operator (from header):', adminUser);
  }

  return true;
}

module.exports = {
  // Auth handler exports
  authenticateRequest: authHandler.authenticateRequest,
  validateSessionAge: authHandler.validateSessionAge,
  requireAuth: authHandler.requireAuth,
  createResponse: authHandler.createResponse,
  parseBody: authHandler.parseBody,
  getPathParams: authHandler.getPathParams,
  getQueryParams: authHandler.getQueryParams,
  getAuthConfig: authHandler.getAuthConfig,

  // CORS utilities
  setRequestContext: authHandler.setRequestContext,
  getCorsOrigin: authHandler.getCorsOrigin,

  // Database authorization (defense-in-depth)
  getUserAuthorizationFromDB: authHandler.getUserAuthorizationFromDB,
  getCachedUserAuthorization: authHandler.getCachedUserAuthorization,

  // Standardized error response helpers
  ERROR_CODES: authHandler.ERROR_CODES,
  createErrorResponse: authHandler.createErrorResponse,
  badRequest: authHandler.badRequest,
  unauthorized: authHandler.unauthorized,
  forbidden: authHandler.forbidden,
  notFound: authHandler.notFound,
  conflict: authHandler.conflict,
  serverError: authHandler.serverError,

  // JWT validator exports
  validateToken: jwtValidator.validateToken,
  validateAuthHeader: jwtValidator.validateAuthHeader,

  // Security utils exports
  hashPassword: securityUtils.hashPassword,
  verifyPassword: securityUtils.verifyPassword,
  generateToken: securityUtils.generateToken,
  generateSessionId: securityUtils.generateSessionId,
  sanitizeInput: securityUtils.sanitizeInput,
  isValidEmail: securityUtils.isValidEmail,
  maskSensitive: securityUtils.maskSensitive,
  extractUserFromToken: securityUtils.extractUserFromToken,

  // Security headers exports
  getSecurityHeaders: securityHeaders.getSecurityHeaders,
  getAuthSecurityHeaders: securityHeaders.getAuthSecurityHeaders,
  mergeSecurityHeaders: securityHeaders.mergeSecurityHeaders,

  // Rate limiting exports
  checkRateLimit: rateLimiter.checkRateLimit,
  getRateLimitHeaders: rateLimiter.getRateLimitHeaders,
  applyRateLimit: rateLimiter.applyRateLimit,
  getClientIp: rateLimiter.getClientIp,
  getRateLimitConfig: rateLimiter.getRateLimitConfig,
  getRateLimitStats: rateLimiter.getRateLimitStats,
  RATE_LIMITS: rateLimiter.RATE_LIMITS,

  // Email utils exports
  sendEmail: emailUtils.sendEmail,
  sendTemplatedEmail: emailUtils.sendTemplatedEmail,
  sendBookingConfirmation: emailUtils.sendBookingConfirmation,
  sendBookingReminder: emailUtils.sendBookingReminder,
  sendVaccinationReminder: emailUtils.sendVaccinationReminder,
  sendCheckInConfirmation: emailUtils.sendCheckInConfirmation,
  sendCheckOutConfirmation: emailUtils.sendCheckOutConfirmation,
  sendBookingCancellation: emailUtils.sendBookingCancellation,
  sendBookingUpdated: emailUtils.sendBookingUpdated,
  emailTemplates: emailUtils.emailTemplates,
  formatDate: emailUtils.formatDate,
  formatDateTime: emailUtils.formatDateTime,

  // Permission exports
  PERMISSIONS: permissions.PERMISSIONS,
  ROLES: permissions.ROLES,
  roleHasPermission: permissions.roleHasPermission,
  userHasPermission: permissions.userHasPermission,
  getUserPermissions: permissions.getUserPermissions,
  requirePermission: permissions.requirePermission,
  checkPermission: permissions.checkPermission,

  // SMS utils exports (Twilio)
  sendSMS: smsUtils.sendSMS,
  sendTemplatedSMS: smsUtils.sendTemplatedSMS,
  sendBookingConfirmationSMS: smsUtils.sendBookingConfirmationSMS,
  sendBookingReminderSMS: smsUtils.sendBookingReminderSMS,
  sendCheckInConfirmationSMS: smsUtils.sendCheckInConfirmationSMS,
  sendCheckOutConfirmationSMS: smsUtils.sendCheckOutConfirmationSMS,
  sendVaccinationReminderSMS: smsUtils.sendVaccinationReminderSMS,
  sendCustomSMS: smsUtils.sendCustomSMS,
  formatPhoneNumber: smsUtils.formatPhoneNumber,
  isSMSConfigured: smsUtils.isSMSConfigured,
  SMS_TEMPLATES: smsUtils.SMS_TEMPLATES,

  // Square POS exports
  squareUtils,
  isSquareConfigured: squareUtils.isSquareConfigured,
  squareCreatePayment: squareUtils.createPayment,
  squareGetPayment: squareUtils.getPayment,
  squareRefundPayment: squareUtils.refundPayment,
  squareCreateCustomer: squareUtils.createCustomer,
  squareSearchCustomer: squareUtils.searchCustomer,
  squareGetOrCreateCustomer: squareUtils.getOrCreateCustomer,
  squareCreateCheckoutLink: squareUtils.createCheckoutLink,
  squareListOrders: squareUtils.listOrders,

  // QuickBooks Online exports
  quickbooksUtils,
  isQuickBooksConfigured: quickbooksUtils.isQuickBooksConfigured,
  qbGetAuthorizationUrl: quickbooksUtils.getAuthorizationUrl,
  qbExchangeCodeForTokens: quickbooksUtils.exchangeCodeForTokens,
  qbRefreshAccessToken: quickbooksUtils.refreshAccessToken,
  qbSyncCustomer: quickbooksUtils.syncCustomer,
  qbCreateInvoice: quickbooksUtils.createInvoice,
  qbRecordPayment: quickbooksUtils.recordPayment,
  qbGetConnectionStatus: quickbooksUtils.getConnectionStatus,

  // Webhook exports
  webhookUtils,
  WEBHOOK_EVENTS: webhookUtils.WEBHOOK_EVENTS,
  generateWebhookSignature: webhookUtils.generateSignature,
  verifyWebhookSignature: webhookUtils.verifySignature,
  sendWebhook: webhookUtils.sendWebhook,
  queueWebhookDeliveries: webhookUtils.queueWebhookDeliveries,
  processPendingDeliveries: webhookUtils.processPendingDeliveries,

  // USDA Form Generation exports
  usdaForms,
  generateForm7001: usdaForms.generateForm7001,
  generateForm7002: usdaForms.generateForm7002,
  generateForm7005: usdaForms.generateForm7005,
  generateVaccinationComplianceReport: usdaForms.generateVaccinationComplianceReport,
  generateInspectionChecklist: usdaForms.generateInspectionChecklist,

  // State Vaccination Rules exports
  vaccinationRules,
  getStateRules: vaccinationRules.getStateRules,
  getSupportedStates: vaccinationRules.getSupportedStates,
  checkVaccinationCompliance: vaccinationRules.checkCompliance,
  getBoardingRequirements: vaccinationRules.getBoardingRequirements,
  calculateNextDueDate: vaccinationRules.calculateNextDueDate,
  STATE_VACCINATION_RULES: vaccinationRules.STATE_VACCINATION_RULES,

  // Audit Trail exports
  auditUtils,
  AUDIT_ACTIONS: auditUtils.AUDIT_ACTIONS,
  ENTITY_TYPES: auditUtils.ENTITY_TYPES,
  DATA_TYPES: auditUtils.DATA_TYPES,
  createAuditLog: auditUtils.createAuditLog,
  createAuthAuditLog: auditUtils.createAuthAuditLog,
  createDataAccessLog: auditUtils.createDataAccessLog,
  createConfigChangeLog: auditUtils.createConfigChangeLog,
  queryAuditLogs: auditUtils.queryAuditLogs,
  getAuditSummary: auditUtils.getAuditSummary,
  extractAuditContext: auditUtils.extractAuditContext,
  maskSensitiveData: auditUtils.maskSensitiveData,

  // Admin path rewriting
  handleAdminPathRewrite,

  // Tier Enforcement exports
  tierEnforcement,
  PLAN_FEATURES: tierEnforcement.PLAN_FEATURES,
  FEATURE_NAMES: tierEnforcement.FEATURE_NAMES,
  TIER_ERROR_CODES: tierEnforcement.TIER_ERROR_CODES,
  hasFeature: tierEnforcement.hasFeature,
  getLimit: tierEnforcement.getLimit,
  isWithinLimit: tierEnforcement.isWithinLimit,
  getUpgradeTier: tierEnforcement.getUpgradeTier,
  getUpgradeTierForLimit: tierEnforcement.getUpgradeTierForLimit,
  enforceFeature: tierEnforcement.enforceFeature,
  enforceLimit: tierEnforcement.enforceLimit,
  createTierErrorResponse: tierEnforcement.createTierErrorResponse,
  withTierEnforcement: tierEnforcement.withTierEnforcement,
  getTenantPlan: tierEnforcement.getTenantPlan,

  // Workflow Events exports
  workflowEvents,
  WORKFLOW_EVENT_TYPES: workflowEvents.WORKFLOW_EVENT_TYPES,
  RECORD_TYPES: workflowEvents.RECORD_TYPES,
  publishWorkflowEvent: workflowEvents.publishWorkflowEvent,
  publishWorkflowEventBatch: workflowEvents.publishWorkflowEventBatch,
  // Booking events
  publishBookingCreated: workflowEvents.publishBookingCreated,
  publishBookingConfirmed: workflowEvents.publishBookingConfirmed,
  publishBookingCheckedIn: workflowEvents.publishBookingCheckedIn,
  publishBookingCheckedOut: workflowEvents.publishBookingCheckedOut,
  publishBookingCancelled: workflowEvents.publishBookingCancelled,
  // Pet events
  publishPetCreated: workflowEvents.publishPetCreated,
  publishPetUpdated: workflowEvents.publishPetUpdated,
  publishPetVaccinationExpiring: workflowEvents.publishPetVaccinationExpiring,
  publishPetVaccinationExpired: workflowEvents.publishPetVaccinationExpired,
  publishPetBirthday: workflowEvents.publishPetBirthday,
  // Owner events
  publishOwnerCreated: workflowEvents.publishOwnerCreated,
  // Payment events
  publishPaymentReceived: workflowEvents.publishPaymentReceived,
  publishPaymentFailed: workflowEvents.publishPaymentFailed,
  // Invoice events
  publishInvoiceOverdue: workflowEvents.publishInvoiceOverdue,
  // Task events
  publishTaskCreated: workflowEvents.publishTaskCreated,
  publishTaskCompleted: workflowEvents.publishTaskCompleted,

  // Account Code Resolver exports (New ID System)
  accountResolver,
  getTenantByAccountCode: accountResolver.getTenantByAccountCode,
  resolveAccountContext: accountResolver.resolveAccountContext,
  rewritePathToLegacy: accountResolver.rewritePathToLegacy,
  validateTypeId: accountResolver.validateTypeId,
  parseNewIdPattern: accountResolver.parseNewIdPattern,
  getAccountCodeFromHeader: accountResolver.getAccountCodeFromHeader,
  getEntityTypeFromId: accountResolver.getEntityTypeFromId,
  OBJECT_TYPE_CODES: accountResolver.OBJECT_TYPE_CODES,
  TYPE_CODE_TO_ENTITY: accountResolver.TYPE_CODE_TO_ENTITY,

  // Crypto Utils exports (OAuth token encryption)
  cryptoUtils,
  encryptToken: cryptoUtils.encryptToken,
  decryptToken: cryptoUtils.decryptToken,
  generateEncryptionKey: cryptoUtils.generateEncryptionKey,
  testEncryption: cryptoUtils.testEncryption,

  // Secrets Manager exports
  secrets,
  fetchSecrets: secrets.fetchSecrets,
  getSecret: secrets.getSecret,
  getDatabaseUrl: secrets.getDatabaseUrl,
  getGoogleClientSecret: secrets.getGoogleClientSecret,
  getTokenEncryptionKey: secrets.getTokenEncryptionKey,
  preloadSecrets: secrets.preloadSecrets,
};
