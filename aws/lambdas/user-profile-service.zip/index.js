// Canonical Service:
// Domain: User Profiles & Permission Assignments
// This Lambda is the authoritative backend for this domain.
// All NEW endpoints for this domain must be implemented here.
// Do NOT add new logic or endpoints to legacy Lambdas for this domain.

/**
 * User Profile Service
 * Manages user-to-profile assignments and permission calculations
 * Implements profile inheritance and effective permission caching
 */

const { getPool, getTenantIdFromEvent, getJWTValidator } = require('/opt/nodejs');
const permissionCalculator = require('./permission-calculator');
const {
  getSecureHeaders,
  errorResponse,
  successResponse,
} = require('/opt/nodejs/security-utils');

const JSON_HEADERS = { 'Content-Type': 'application/json' };

// Enhanced authorization with fallback JWT validation
async function getUserInfoFromEvent(event) {
    // First, try to get claims from API Gateway JWT authorizer
    const claims = event?.requestContext?.authorizer?.jwt?.claims;

    if (claims && claims.sub) {
        console.log('[AUTH] Using API Gateway JWT claims');
        return {
            userId: claims.sub,
            email: claims.email || claims['cognito:username'],
            tenantId: claims.tenantId || claims['custom:tenantId'],
            role: claims.role || claims['custom:role']
        };
    }

    // Fallback: Manually validate the JWT token
    console.log('[AUTH] No API Gateway claims, falling back to manual JWT validation');
    const authHeader = event?.headers?.authorization || event?.headers?.Authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        console.log('[AUTH] No Authorization header');
        return null;
    }

    const token = authHeader.substring(7);

    try {
        const jwtValidator = getJWTValidator();
        const validationResult = await jwtValidator.validateToken(token);
        const userInfo = jwtValidator.extractUserInfo(validationResult.decoded, validationResult.tokenType);
        return userInfo;
    } catch (error) {
        console.error('[AUTH] JWT validation failed:', error.message);
        return null;
    }
}

const ok = (event, statusCode, data = '', additionalHeaders = {}) => {
  if (statusCode === 204) {
    const origin = event?.headers?.origin || event?.headers?.Origin;
    const stage = process.env.STAGE || 'development';
    return {
      statusCode,
      headers: {
        ...getSecureHeaders(origin, stage),
        ...JSON_HEADERS,
        ...additionalHeaders,
      },
      body: '',
    };
  }

  return successResponse(statusCode, data, event, {
    ...JSON_HEADERS,
    ...additionalHeaders,
  });
};

const fail = (event, statusCode, errorCodeOrBody, message, additionalHeaders = {}) => {
  if (typeof errorCodeOrBody === 'object' && errorCodeOrBody !== null) {
    const origin = event?.headers?.origin || event?.headers?.Origin;
    const stage = process.env.STAGE || 'development';
    return {
      statusCode,
      headers: {
        ...getSecureHeaders(origin, stage),
        ...JSON_HEADERS,
        ...additionalHeaders,
      },
      body: JSON.stringify(errorCodeOrBody),
    };
  }

  const response = errorResponse(statusCode, errorCodeOrBody, message, event);
  return {
    ...response,
    headers: {
      ...response.headers,
      ...JSON_HEADERS,
      ...additionalHeaders,
    },
  };
};

exports.handler = async (event) => {

  const { method, path } = event.requestContext.http;
  const pathParams = event.pathParameters || {};
  const queryParams = event.queryStringParameters || {};
  const body = event.body ? JSON.parse(event.body) : {};

  // Extract tenant context
  const tenantId = await getTenantIdFromEvent(event);
  if (!tenantId) {
    return fail(event, 401, { error: 'Missing tenant context' });
  }

  // Extract user info with fallback JWT validation
  const userInfo = await getUserInfoFromEvent(event);
  const currentUserId = userInfo?.userId || null;

  console.log('[ROUTING DEBUG]', {
    route: path,
    method,
    tenantId,
    userId: currentUserId,
  });

  try {
    // Route: GET /api/v1/users/profile
    if (method === 'GET' && path === '/api/v1/users/profile') {
      return await getCurrentUserProfile(event, currentUserId, tenantId);
    }

    // Route: PATCH /api/v1/users/profile
    if (method === 'PATCH' && path === '/api/v1/users/profile') {
      return await updateCurrentUserProfile(currentUserId, tenantId, body);
    }

    // Route: GET /api/v1/profiles
    if (method === 'GET' && path.endsWith('/profiles')) {
      return await listProfiles(event, tenantId);
    }

    // Route: GET /api/v1/profiles/{profileId}
    if (method === 'GET' && path.match(/\/profiles\/\d+$/)) {
      const profileId = parseInt(pathParams.profileId, 10);
      return await getProfile(event, profileId, tenantId);
    }

    // Route: GET /api/v1/users/{userId}/profiles
    if (method === 'GET' && path.match(/\/users\/[^/]+\/profiles$/)) {
      const userId = pathParams.userId;
      return await getUserProfiles(event, userId, tenantId);
    }

    // Route: POST /api/v1/users/{userId}/profiles
    if (method === 'POST' && path.match(/\/users\/[^/]+\/profiles$/)) {
      const userId = pathParams.userId;
      return await assignProfile(event, userId, tenantId, body, currentUserId);
    }

    // Route: DELETE /api/v1/users/{userId}/profiles/{profileId}
    if (method === 'DELETE' && path.match(/\/users\/[^/]+\/profiles\/\d+$/)) {
      const userId = pathParams.userId;
      const profileId = parseInt(pathParams.profileId, 10);
      return await unassignProfile(event, userId, tenantId, profileId, currentUserId);
    }

    // Route: GET /api/v1/users/{userId}/effective-permissions
    if (method === 'GET' && path.match(/\/users\/[^/]+\/effective-permissions$/)) {
      const userId = pathParams.userId;
      const objectType = queryParams.objectType;
      return await getEffectivePermissions(event, userId, tenantId, objectType);
    }

    // Route: POST /api/v1/permissions/calculate
    if (method === 'POST' && path.endsWith('/permissions/calculate')) {
      return await calculatePermissions(event, body.userId, tenantId, body.propertyId);
    }

    // Route: POST /api/v1/permissions/invalidate-cache
    if (method === 'POST' && path.endsWith('/permissions/invalidate-cache')) {
      return await invalidateCache(event, body.userId, tenantId);
    }

    return fail(event, 404, { error: 'Route not found' });
  } catch (error) {
    console.error('Error in user-profile-service:', error);
    return fail(event, 500, { error: error.message });
  }
};

/**
 * List all permission profiles
 */
async function listProfiles(event, tenantId) {
  const pool = getPool();

  const result = await pool.query(
    `SELECT 
      pp.*,
      parent."profile_name" AS parent_profile_name,
      (SELECT COUNT(*) FROM "UserProfileAssignment" upa 
       WHERE upa."profile_id" = pp."profile_id" 
         AND upa."tenant_id" = $1
         AND upa."is_active" = true) AS user_count
    FROM "PermissionProfile" pp
    LEFT JOIN "PermissionProfile" parent ON pp."parent_profile_id" = parent."profile_id"
    WHERE (pp."tenant_id" = $1 OR pp."is_global" = true)
      AND pp."is_active" = true
    ORDER BY pp."hierarchy_level" DESC, pp."display_order"`,
    [tenantId]
  );

  return ok(event, 200, result.rows);
}

/**
 * Get a specific profile
 */
async function getProfile(event, profileId, tenantId) {
  const pool = getPool();

  const result = await pool.query(
    `SELECT 
      pp.*,
      parent."profile_name" AS parent_profile_name,
      (SELECT COUNT(*) FROM "PropertyPermission" pperm 
       WHERE pperm."profile_id" = pp."profile_id") AS permission_count,
      (SELECT COUNT(*) FROM "UserProfileAssignment" upa 
       WHERE upa."profile_id" = pp."profile_id" 
         AND upa."tenant_id" = $2
         AND upa."is_active" = true) AS user_count
    FROM "PermissionProfile" pp
    LEFT JOIN "PermissionProfile" parent ON pp."parent_profile_id" = parent."profile_id"
    WHERE pp."profile_id" = $1
      AND (pp."tenant_id" = $2 OR pp."is_global" = true)`,
    [profileId, tenantId]
  );

  if (result.rows.length === 0) {
    return fail(event, 404, { error: 'Profile not found' });
  }

  return ok(event, 200, result.rows[0]);
}

/**
 * Get profiles assigned to a user
 */
async function getUserProfiles(event, userId, tenantId) {
  const pool = getPool();

  const result = await pool.query(
    `SELECT 
      upa.*,
      pp."profile_name",
      pp."profile_key",
      pp."description",
      pp."hierarchy_level",
      pp."icon",
      pp."color"
    FROM "UserProfileAssignment" upa
    INNER JOIN "PermissionProfile" pp ON upa."profile_id" = pp."profile_id"
    WHERE upa."user_id" = $1
      AND upa."tenant_id" = $2
      AND upa."is_active" = true
      AND (upa."expires_at" IS NULL OR upa."expires_at" > NOW())
    ORDER BY upa."is_primary" DESC, pp."hierarchy_level" DESC`,
    [userId, tenantId]
  );

  return ok(event, 200, result.rows);
}

/**
 * Assign a profile to a user
 */
async function assignProfile(event, userId, tenantId, data, assignedBy) {
  const pool = getPool();
  const { profileId, isPrimary, expiresAt, reason } = data;

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // If setting as primary, unset other primary assignments
    if (isPrimary) {
      await client.query(
        `UPDATE "UserProfileAssignment"
         SET "is_primary" = false
         WHERE "user_id" = $1
           AND "tenant_id" = $2
           AND "is_primary" = true`,
        [userId, tenantId]
      );
    }

    // Insert assignment
    const result = await client.query(
      `INSERT INTO "UserProfileAssignment" (
        "user_id",
        "profile_id",
        "tenant_id",
        "is_primary",
        "expires_at",
        "assignment_reason",
        "assigned_by"
      ) VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *`,
      [userId, profileId, tenantId, isPrimary || false, expiresAt, reason, assignedBy]
    );

    // Invalidate permission cache
    await client.query(
      `UPDATE "EffectivePermissionCache"
       SET "is_valid" = false
       WHERE "user_id" = $1 AND "tenant_id" = $2`,
      [userId, tenantId]
    );

    await client.query('COMMIT');

    return ok(event, 201, result.rows[0]);
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Unassign a profile from a user
 */
async function unassignProfile(event, userId, tenantId, profileId, unassignedBy) {
  const pool = getPool();

  const result = await pool.query(
    `UPDATE "UserProfileAssignment"
     SET "is_active" = false
     WHERE "user_id" = $1
       AND "tenant_id" = $2
       AND "profile_id" = $3
     RETURNING *`,
    [userId, tenantId, profileId]
  );

  if (result.rowCount === 0) {
    return fail(event, 404, { error: 'Profile assignment not found' });
  }

  // Invalidate permission cache
  await pool.query(
    `UPDATE "EffectivePermissionCache"
     SET "is_valid" = false
     WHERE "user_id" = $1 AND "tenant_id" = $2`,
    [userId, tenantId]
  );

  return ok(event, 200, { message: 'Profile unassigned successfully' });
}

/**
 * Get effective permissions for a user
 */
async function getEffectivePermissions(event, userId, tenantId, objectType) {
  const pool = getPool();

  const result = await pool.query(
    'SELECT * FROM get_accessible_properties($1, $2, $3, $4)',
    [userId, tenantId, objectType || null, 'read-only']
  );

  return ok(event, 200, result.rows);
}

/**
 * Calculate permissions for a specific property
 */
async function calculatePermissions(event, userId, tenantId, propertyId) {
  const effectiveAccess = await permissionCalculator.calculate(userId, tenantId, propertyId);

  return ok(event, 200, {
    userId,
    tenantId,
    propertyId,
    effectiveAccess,
  });
}

/**
 * Invalidate permission cache for a user
 */
async function invalidateCache(event, userId, tenantId) {
  const pool = getPool();

  const result = await pool.query(
    `UPDATE "EffectivePermissionCache"
     SET "is_valid" = false
     WHERE "user_id" = $1 AND "tenant_id" = $2`,
    [userId, tenantId]
  );

  return ok(event, 200, {
    message: 'Permission cache invalidated',
    invalidatedCount: result.rowCount,
  });
}

async function getCurrentUserProfile(event, userId, tenantId) {
  if (!userId) {
    return fail(event, 401, { error: 'Unauthorized' });
  }

  const pool = getPool();
  // Support both custom tokens (sub = recordId) and Cognito tokens (sub = cognitoSub)
  const { rows } = await pool.query(
    `SELECT 
      u."recordId",
      u."email",
      u."name",
      u."phone",
      u."avatarUrl",
      u."createdAt",
      u."updatedAt",
      m."role" AS "membershipRole",
      m."tenantId" AS "membershipTenantId"
     FROM "User" u
     LEFT JOIN "Membership" m ON m."userId" = u."recordId" AND m."tenantId" = $2
     WHERE u."recordId" = $1 OR u."cognitoSub" = $1`,
    [userId, tenantId]
  );

  if (rows.length === 0) {
    return fail(event, 404, { error: 'User not found' });
  }

  const profile = rows[0];

  return ok(event, 200, {
    recordId: profile.recordId,
    email: profile.email,
    name: profile.name,
    phone: profile.phone,
    avatarUrl: profile.avatarUrl,
    createdAt: profile.createdAt,
    updatedAt: profile.updatedAt,
    role: profile.membershipRole,
    tenantId: profile.membershipTenantId || tenantId,
  });
}

async function updateCurrentUserProfile(event, userId, tenantId, data = {}) {
  if (!userId) {
    return fail(event, 401, { error: 'Unauthorized' });
  }

  const allowedFields = ['name', 'phone', 'avatarUrl'];
  const updates = [];
  const values = [];

  allowedFields.forEach((field) => {
    if (data[field] !== undefined) {
      updates.push(`"${field}" = $${updates.length + 1}`);
      values.push(data[field]);
    }
  });

  if (updates.length === 0) {
    return fail(event, 400, { error: 'No valid fields provided' });
  }

  values.push(userId);

  const pool = getPool();
  // Support both custom tokens (sub = recordId) and Cognito tokens (sub = cognitoSub)
  const result = await pool.query(
    `UPDATE "User"
     SET ${updates.join(', ')}, "updatedAt" = NOW()
     WHERE "recordId" = $${values.length} OR "cognitoSub" = $${values.length}
     RETURNING "recordId"`,
    values
  );

  if (result.rowCount === 0) {
    return fail(event, 404, { error: 'User not found' });
  }

  return await getCurrentUserProfile(event, userId, tenantId);
}

